"""Ignition-owned interpretation of PLC interface v4. Pure Jython-compatible rules.

Raw capture is evidence; only explicit physical facts become workflow events.
Numbered workflow states are defined in domain.STATE_NAMES.
"""
from copy import deepcopy
from datetime import datetime
from decimal import Decimal
import hashlib
from washheat import domain

IDENTITY_FIELDS = (("SN", "serial_number"), ("WO", "work_order"), ("PN", "part_number"),
                   ("Stage", "stage"), ("QA", "qa_spec"), ("Recipe", "press_recipe"), ("PressQA", "press_qa"))


def integer(value, name, low=0, high=2147483646):
    result = domain.number(value, name)
    if result != result.to_integral_value() or not low <= result <= high:
        raise domain.RuleError(name + " outside integral range")
    return int(result)


def signed(value):
    # Installation UUID words are signed DINTs; domain.number is nonnegative.
    if isinstance(value, bool) or str(value) != str(int(value)) or not -2147483648 <= int(value) <= 2147483647:
        raise domain.RuleError("Invalid installation word")
    return int(value)


def installation(raw):
    if len(raw) != 4:
        raise domain.RuleError("Installation requires four DINTs")
    result = [signed(v) for v in raw]
    if not any(result):
        raise domain.RuleError("Installation is not assigned")
    return result


def string(raw):
    length = integer(raw["LEN"], "legacy string length", 1, 32)
    if len(raw["DATA"]) != 32:
        raise domain.RuleError("Legacy string storage must contain 32 bytes")
    return "".join(chr(integer(v, "identity byte", 32, 126)) for v in raw["DATA"][:length])


def identity(raw):
    result = dict((name, string(raw[field])) for field, name in IDENTITY_FIELDS)
    if len(raw["LoadStamp"]) != 7:
        raise domain.RuleError("Load stamp must contain seven original values")
    result["load_stamp"] = [integer(v, "load stamp") for v in raw["LoadStamp"]]
    return result


def item_identity(raw):
    names = ("strSN", "strWO", "strPN", "strStg", "strQA", "strRecipe", "strPressQA")
    result = dict((field, raw[name]) for (field, _), name in zip(IDENTITY_FIELDS, names))
    result["LoadStamp"] = [raw["TimeStampIn"][n] for n in ("Year", "Month", "Day", "Hour", "Minute", "Second", "Microsecond")]
    return identity(result)


def timestamp(raw):
    if len(raw) != 7:
        raise domain.RuleError("Capture timestamp requires seven components")
    fields = [integer(v, "capture date component", 0, 999999) for v in raw]
    try:
        delta = datetime(*fields) - datetime(1970, 1, 1)
    except ValueError:
        raise domain.RuleError("Invalid PLC capture timestamp")
    # CDL/physical source UTC or FDC arrival UTC for the compact press counter.
    return domain.millis(delta.days * 86400000 + delta.seconds * 1000 + delta.microseconds // 1000)


def digest(value):
    return hashlib.sha256(domain.canonical(value).encode("utf-8")).hexdigest()


def channel_key(packet):
    return [domain.text(packet["Controller"], "controller"), installation(packet["Installation"]),
            integer(packet["Boot"], "boot", 1), integer(packet["Furnace"], "furnace", 1, 2),
            integer(packet["Slot"], "slot", 1, 96)]


def event_key(packet):
    return channel_key(packet) + [integer(packet["Sequence"], "event sequence", 1)]


def binding_key(packet, part):
    key = channel_key(packet)
    return digest(key[:3] + [part])  # Slot may change; full part/load identity cannot.


def return_key(packet, sequence):
    return channel_key(packet) + [integer(sequence, "physical return sequence", 1)]


def approved(packet):
    for name in ("MappingApproved", "ClockValidated", "QualifyingSourceApproved"):
        if packet[name] != 1:
            raise domain.RuleError(name + " is not valid")
    frame = packet["Physical"]
    if frame["BindingValid"] != 1 or frame["QualifyingValid"] != 1:
        raise domain.RuleError("Physical/qualifying source quality invalid")
    if frame["OriginFurnace"] != packet["Furnace"]:
        raise domain.RuleError("Return must remain in the original furnace")


def qualifying(state, frame, previous=None):
    total = integer(frame["QualifyingMs"], "qualifying milliseconds")
    maximum = integer(frame["MaximumSoakMs"], "maximum qualifying milliseconds", 1)
    expected = domain.number(state["max_qualifying_soak_seconds"], "run maximum") * 1000
    floor = domain.number(state["qualifying_soak_seconds"], "previous qualifying") * 1000
    if previous and "qualifying_ms" in previous:
        floor = max(floor, previous["qualifying_ms"])
    if maximum != expected or total < floor:
        raise domain.RuleError("Qualifying counter regressed or original run maximum changed")
    return total


def events(state, packet, previous=None):
    """All validations finish before any derived workflow event is persisted."""
    if packet["PhysicalIsNew"] == 0:
        return []
    if packet["PhysicalIsNew"] != 1:
        raise domain.RuleError("Invalid PhysicalIsNew flag")
    approved(packet)
    frame = packet["Physical"]
    for name in ("ReturnConfirmed", "Removal", "CycleStart"):
        integer(frame[name], name, 0, 1)
    if sum(frame[n] for n in ("ReturnConfirmed", "Removal", "CycleStart")) > 1:
        raise domain.RuleError("Conflicting physical events")
    part = identity(frame["Identity"])
    if part != state["plc_binding"]["identity"]:
        raise domain.RuleError("Captured identity does not match bound run")
    if packet["Furnace"] != domain.FURNACES.index(state["furnace"]) + 1:
        raise domain.RuleError("Physical event belongs to another furnace")
    if not frame["ReturnConfirmed"] and packet["Slot"] != state["plc_binding"]["slot"]:
        raise domain.RuleError("Physical event is not at the run's current slot")
    source_item = packet["BoundItem"]
    if item_identity(source_item) != part:
        raise domain.RuleError("Legacy snapshot and physical identity disagree")
    total = qualifying(state, frame, previous)
    occurred = timestamp(frame["OccurredUTC"])
    if occurred > timestamp(packet["CapturedUTC"]):
        raise domain.RuleError("Source timestamp is later than FDC capture; check clock synchronization")
    cdl_id = integer(frame['CdlId'], 'CDL adapter', 1, 2)
    press = integer(frame['Press'], 'selected press', 50, 300)
    if press not in (50, 300):
        raise domain.RuleError('Selected press must be 50 or 300 MN')
    base = {"at_ms": occurred, "actor": "PLC_CAPTURE", "quality": "GOOD", 'cdl_id':cdl_id, 'press':press}
    if frame['CycleStart']:
        base.update(timing_basis='FDC_ARRIVAL', uncertainty_ms=1000, observed_at_ms=occurred)
        if occurred < state['last_event_at_ms'] <= occurred + 1000:
            base['at_ms'] = state['last_event_at_ms']
    result = [dict(base, type="SOAK_READING", qualifying_soak_seconds=str(Decimal(total) / 1000))]
    if frame["ReturnConfirmed"]:
        controls = source_item["Control"]
        if controls["stsEmpty"] or controls["stsStamped"] or not controls["stsWashHeat"]:
            raise domain.RuleError("Returned item status is inconsistent")
        if packet["TimerValid"] != 1 or packet["TimerReturnSequence"] != frame["Sequence"]:
            raise domain.RuleError("Physical return timer is not correlated")
        slot = packet["Slot"] - 1
        result.append(dict(base, type="RETURN", furnace=state["furnace"],
                           segment="%02d%s" % (slot // 4 + 1, "ABCD"[slot % 4]),
                           plc_return_key=return_key(packet, frame["Sequence"])))
    elif frame["Removal"]:
        result.append(dict(base, type="REMOVE"))
    elif frame["CycleStart"]:
        result.append(dict(base, type="CYCLE_START"))
    decision = integer(frame["Decision"], "CDL operator decision", 0, 3)
    if decision == 3 or (decision and any(frame[n] for n in ("ReturnConfirmed", "Removal", "CycleStart"))):
        raise domain.RuleError("Conflicting CDL decision/physical observations")
    if decision:
        result.append(dict(base, type="UNLOAD_OK" if decision == 1 else "UNLOAD_NOT_OK",
                           actor="CDL_HMI_UNATTRIBUTED", reason="Source-captured CDL HMI selection; individual operator/reason not supplied by legacy tags"))
    # The broadcast command mask stays contextual. Only the owner-bound,
    # sequenced HMI observation becomes a decision; it has no invented username.
    for index, event in enumerate(result):
        event["event_id"] = digest([event_key(packet), index])
    candidate = state
    for event in result:
        candidate = domain.apply_event(candidate, event)
    return result


def sample(state, packet, previous, received_at_ms):
    result = {"valid": False, "received_at_ms": domain.millis(received_at_ms)}
    if previous:
        # Retain the high-water marks across bad-quality observations.
        for key in ("qualifying_ms", "elapsed_ms", "return_key"):
            if key in previous:
                result[key] = deepcopy(previous[key])
    try:
        sequence = integer(packet["SampleSequence"], "sample sequence", 1)
        source_digest = digest(packet)
        approved(packet)
        channel = channel_key(packet)
        key = channel
        if key[:3] != state["plc_binding"]["epoch"] or packet["Slot"] != state["plc_binding"]["slot"]:
            raise domain.RuleError("Sample epoch/channel changed")
        if packet["Furnace"] != domain.FURNACES.index(state["furnace"]) + 1:
            raise domain.RuleError("Sample furnace changed")
        if previous and channel == previous.get("source_channel") and sequence == previous.get("source_sample_sequence"):
            if source_digest != previous.get("source_digest"):
                raise domain.RuleError("Sample content changed under the same sequence")
            # Revalidate against current workflow, retaining the original age.
            result["received_at_ms"] = previous["received_at_ms"]
        if packet["Fault"] != 0 or packet["CaptureState"] == 900:
            raise domain.RuleError("PLC capture/timer fault")
        if identity(packet["Physical"]["Identity"]) != state["plc_binding"]["identity"]:
            raise domain.RuleError("Current physical identity changed")
        total = qualifying(state, packet["Physical"], previous)
        if domain.state_number(state) in (10, 50, 70):
            if identity(packet["CurrentIdentity"]) != state["plc_binding"]["identity"]:
                raise domain.RuleError("Current slot item identity changed")
        elapsed = integer(packet["ElapsedMs"], "elapsed milliseconds")
        key = None
        if domain.state_number(state) in (50, 70):
            if packet["ItemEmpty"] or packet["ItemStamped"] or packet["ItemWashHeat"] != 1:
                raise domain.RuleError("Current item status is inconsistent with a returned wash part")
            key = return_key(packet, packet["TimerReturnSequence"])
            if key != state["episodes"][-1]["plc_return_key"] or packet["TimerValid"] != 1 or packet["TimerState"] != 10:
                raise domain.RuleError("Wrong return timer or stopped timer")
            if previous and previous.get("return_key") == key and elapsed < previous.get("elapsed_ms", 0):
                raise domain.RuleError("Physical elapsed timer regressed")
        result.update(valid=True, qualifying_ms=total, elapsed_ms=elapsed, return_key=key,
                      timer_state=packet["TimerState"], reason=None,
                      source_channel=channel, source_sample_sequence=sequence, source_digest=source_digest)
    except (domain.RuleError, KeyError, ValueError, TypeError) as error:
        result["reason"] = str(error)
    return result


def cdl_key(packet):
    return [domain.text(packet["Controller"], "CDL controller"), installation(packet["Installation"]),
            integer(packet["Boot"], "CDL boot", 1), "CDL_RAW_TIMER"]

