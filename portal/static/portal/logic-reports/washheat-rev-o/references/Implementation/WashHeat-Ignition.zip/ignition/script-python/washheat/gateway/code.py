"""PLC interface v4 OPC adapter; Gateway scope, one dedicated fixed-delay caller.

Configure ENABLED/DEVICE/SLOTS after mapping the PLC-local physical source frame.
Writes durable capture receipts and persisted, load-correlated transfer limits.
"""
import time
import traceback
from washheat import capture, domain, ingestion, service

ENABLED = False
OPC_SERVER = "Ignition OPC UA Server"
DEVICE = ""
CONTROLLER = "FGGW01CLX"
SLOTS = ()
CDL_DEVICE = ""
CDL_CONTROLLER = "PA166_FIRTH_RIXSON"
CDL_INSTALLATION = (0, 0, 0, 0)  # Gateway archival epoch; configure on a new CDL download/restore.


def structure(kind):
    string = {"LEN": None, "DATA": [None] * 32}
    identity = dict((n, string) for n, _ in capture.IDENTITY_FIELDS)
    identity["LoadStamp"] = [None] * 7
    physical = dict((n, None) for n in ("Sequence", "BindingValid", "ReturnConfirmed", "Removal", "CycleStart", "Decision", "WashAuthorized", "OriginFurnace", "QualifyingValid", "QualifyingMs", "MaximumSoakMs", "CdlId", "Press"))
    physical["Identity"] = identity
    physical["OccurredUTC"] = [None] * 7
    common = {"Installation": [None] * 4, "Boot": None, "Furnace": None, "Slot": None,
              "MappingApproved": None, "ClockValidated": None, "QualifyingSourceApproved": None,
              "Physical": physical}
    if kind == "Event":
        item = dict((n, string) for n in ("strSN", "strWO", "strPN", "strStg", "strQA", "strRecipe", "strPressQA"))
        item["TimeStampIn"] = dict((n, None) for n in ("Year", "Month", "Day", "Hour", "Minute", "Second", "Microsecond"))
        item["Control"] = dict((n, None) for n in ("stsEmpty", "stsStamped", "stsWashHeat"))
        common.update(Sequence=None, CommandMask=None, PhysicalIsNew=None, CapturedUTC=[None] * 7,
                       Before=item, After=item, BoundItem=item, TimerReturnSequence=None, TimerValid=None, ElapsedMs=None)
    elif kind == "State":
        common.update(SampleSequence=None, EventSequence=None, Fault=None, CaptureState=None, TimerState=None,
                      ItemEmpty=None, ItemStamped=None, ItemWashHeat=None,
                      TimerReturnSequence=None, TimerValid=None, ElapsedMs=None, CurrentIdentity=identity)
    else:
        raise ValueError("Unsupported packet kind")
    return common


def leaves(shape, prefix=""):
    if isinstance(shape, dict):
        result = []
        for key in sorted(shape):
            result.extend(leaves(shape[key], prefix + ("." if prefix else "") + key))
        return result
    if isinstance(shape, list):
        result = []
        for index, child in enumerate(shape):
            result.extend(leaves(child, prefix + "[%d]" % index))
        return result
    return [prefix]


def assemble(shape, values):
    iterator = iter(values)
    def visit(node):
        if isinstance(node, dict):
            return dict((key, visit(node[key])) for key in sorted(node))
        if isinstance(node, list):
            return [visit(child) for child in node]
        return next(iterator)
    return visit(shape)


def read_values(paths):
    values = system.opc.readValues(OPC_SERVER, paths)
    if len(values) != len(paths) or any(not v.quality.isGood() for v in values):
        raise ValueError("Bad/unknown OPC read quality")
    return [v.value for v in values]


def root(kind, index):
    index = capture.integer(index, "slot index", 0, 191)
    if not DEVICE or "]" in DEVICE:
        raise ValueError("Configure the FDC OPC device")
    return "ns=1;s=[%s]WH_%s[%d]" % (DEVICE, kind, index)


def read_packet(kind, index):
    base = root(kind, index)
    marker = "Sequence" if kind == "Event" else "SampleSequence"
    header = [marker, "Boot"] + ["Installation[%d]" % n for n in range(4)]
    shape = structure(kind)
    fields = leaves(shape)
    for attempt in range(3):
        first = read_values([base + "." + name for name in header])
        if first[0] <= 0:
            return None
        values = read_values([base + "." + name for name in fields])
        last = read_values([base + "." + name for name in header])
        body_header = [values[fields.index(n)] for n in header]
        if first == last == body_header:
            packet = assemble(shape, values)
            packet["Controller"] = CONTROLLER
            if (packet["Furnace"] - 1) * 96 + packet["Slot"] - 1 != index:
                raise ValueError("OPC channel address/payload mismatch")
            return packet
    return None


def write_values(paths, values):
    results = system.opc.writeValues(OPC_SERVER, paths, values)
    if len(results) != len(paths) or any(not q.isGood() for q in results):
        raise ValueError("PLC interface write failed")


def receipt(index, packet):
    base = root("Receipt", index)
    write_values([base + ".Sequence"], [0])
    fields = ["Installation[%d]" % n for n in range(4)] + ["Boot"]
    write_values([base + "." + n for n in fields], packet["Installation"] + [packet["Boot"]])
    write_values([base + ".Sequence"], [packet["Sequence"]])


def publish_transfer_limit(index, sample):
    """SQL is authoritative; invalidate first and commit Valid last."""
    state = service.bound_run(CONTROLLER, index)
    base = root("TransferLimit", index)
    write_values([base + ".Valid"], [0])
    if not state or state["transfer_limit"]["status"] != "CALCULATED":
        return
    if domain.state_number(state) not in (10, 20, 30, 40, 50, 70):
        return
    capture.approved(sample)
    binding = state["plc_binding"]
    if ((sample['Furnace'] - 1) * 96 + sample['Slot'] - 1 != index or
            sample['Furnace'] != domain.FURNACES.index(state['furnace']) + 1 or
            binding['slot'] != sample['Slot'] or
            binding["epoch"] != capture.channel_key(sample)[:3] or
            binding["identity"] != capture.identity(sample["Physical"]["Identity"])):
        return
    fields = ["Boot", "Milliseconds"] + ["LoadStamp[%d]" % n for n in range(7)]
    values = [sample["Boot"], state["transfer_limit"]["milliseconds"]] + binding["identity"]["load_stamp"]
    write_values([base + "." + n for n in fields], values)
    write_values([base + ".Valid"], [1])


def poll_slot(index, telemetry=True):
    packet = read_packet("Event", index)
    if packet:
        ingestion.ingest(packet, int(time.time() * 1000))
        receipt(index, packet)
    if telemetry:
        sample = read_packet("State", index)
        if sample:
            ingestion.observe(sample, int(time.time() * 1000))
            publish_transfer_limit(index, sample)


def poll():
    if not ENABLED:
        return
    pending_samples = []
    for index in SLOTS:
        try:
            poll_slot(index, telemetry=False)
            pending_samples.append(index)
        except:
            # Includes Java OPC/SQL exceptions on Jython. No receipt follows a
            # failed commit. A technical fault cannot leave a green display.
            error = "PLC capture/poll failed: " + traceback.format_exc()
            try:
                ingestion.invalidate(CONTROLLER, index, error)
            finally:
                system.util.getLogger("WashHeatCapture").error(error)
    # Admit all selected channel events before evaluating cross-slot telemetry.
    for index in pending_samples:
        try:
            sample = read_packet("State", index)
            if sample:
                ingestion.observe(sample, int(time.time() * 1000))
                publish_transfer_limit(index, sample)
        except:
            error = "PLC telemetry/poll failed: " + traceback.format_exc()
            try:
                ingestion.invalidate(CONTROLLER, index, error)
            finally:
                system.util.getLogger("WashHeatCapture").error(error)
    if CDL_DEVICE:
        try:
            poll_cdl()
        except:
            system.util.getLogger("WashHeatCapture").error("CDL observation poll failed: " + traceback.format_exc())


def poll_cdl():
    epoch = capture.installation(CDL_INSTALLATION)
    base = "ns=1;s=[%s]WH_CDL_Event" % CDL_DEVICE
    fields = ["Sequence", "Boot", "Kind", "Furnace", "TimerMs", "At33000", "At5000", "Enter300MN"]
    fields += ["%s[%d]" % (name, n) for name in ("StartedUTC", "CapturedUTC") for n in range(7)]
    header_paths = [base + ".Sequence", base + ".Boot"]
    first = read_values(header_paths)
    if first[0] <= 0:
        return
    values = read_values([base + "." + field for field in fields])
    if first != read_values(header_paths) or first != values[:2]:
        return
    packet = dict(zip(fields[:8], values[:8]))
    packet.update(Controller=CDL_CONTROLLER, Installation=epoch, StartedUTC=values[8:15], CapturedUTC=values[15:22])
    ingestion.ingest_cdl(packet, int(time.time() * 1000))
    ack = "ns=1;s=[%s]WH_CDL_" % CDL_DEVICE
    write_values([ack + "AckSequence"], [0])
    write_values([ack + "AckBoot"], [packet["Boot"]])
    write_values([ack + "AckSequence"], [packet["Sequence"]])

