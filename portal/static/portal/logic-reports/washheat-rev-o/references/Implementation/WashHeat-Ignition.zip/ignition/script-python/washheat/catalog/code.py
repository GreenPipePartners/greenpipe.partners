"""Part/operation dimensions, decoded barcode mapping and immutable revisions.

Jython 2.7 compatible. Values are inches/seconds; no dimension is inferred from
a recipe name or the sample ticket. Five exact key fields avoid broad QA matches.
"""
import json
import uuid
from decimal import Decimal
from washheat import domain, service

KEY_FIELDS = ('part_number', 'stage', 'qa_spec', 'press_recipe', 'press_qa')
BARCODE_FIELDS = ('serial_number', 'work_order', 'stage', 'part_number', 'qa_spec',
                  'temperature_sp', 'temperature_tolerance', 'min_soak_minutes',
                  'max_soak_minutes', 'press_recipe', 'press_qa')
DIMENSIONS = ('od_in', 'height_in', 'circle_in')
TIMING = ('max_transfer_seconds', 'dh_cycle_start_seconds', 'dh_tonnage_seconds')
FIELDS = KEY_FIELDS + DIMENSIONS + TIMING + ('active', 'notes')


def parse_barcode(raw):
    # FDC's source parser is comma-delimited, not quoted CSV. Preserve stage zeros.
    raw = domain.text(raw, 'barcode', 1024)
    values = raw.split(',')
    if len(values) == 1:
        raise domain.RuleError('Serial-only barcode: scan the larger 11-field process barcode.')
    if len(values) != len(BARCODE_FIELDS):
        raise domain.RuleError('Expected exactly 11 comma-separated process fields.')
    result = dict((key, domain.text(value, key, 32)) for key, value in zip(BARCODE_FIELDS, values))
    for key in ('temperature_sp','temperature_tolerance','min_soak_minutes','max_soak_minutes'):
        domain.number(result[key], key)
    if domain.number(result['max_soak_minutes'], 'maximum soak') < domain.number(result['min_soak_minutes'], 'minimum soak'):
        raise domain.RuleError('Maximum soak is less than minimum soak.')
    return result


def key(data):
    return dict((field, domain.text(data.get(field), field, 32)) for field in KEY_FIELDS)


def decimal_input(value, name, required=False):
    if value in (None, '') and not required:
        return None
    number = domain.number(value, name, required)
    if number >= Decimal('1000000000000') or number != number.quantize(Decimal('0.000001')):
        raise domain.RuleError(name + ' must fit decimal(18,6), without rounding.')
    return str(number)


def validate(data):
    result = key(data)
    result.update((field, decimal_input(data.get(field), field, field != 'circle_in')) for field in DIMENSIONS)
    result.update((field, decimal_input(data.get(field), field)) for field in TIMING)
    populated = sum(result[field] is not None for field in TIMING)
    if populated not in (0, 3):
        raise domain.RuleError('Enter all three FM20 timing inputs, or leave all three blank.')
    if populated:
        domain.calculate_transfer_limit(result)
    domain.calculate_reheat(result['od_in'], result['height_in'], result['circle_in'], 0)
    active = data.get('active', True)
    if active not in (True, False, 0, 1):
        raise domain.RuleError('Active must be a boolean.')
    result['active'] = bool(active)
    notes = data.get('notes') or ''
    result['notes'] = domain.text(notes, 'notes', 1024) if notes.strip() else ''
    return result


def row_dict(row):
    result = dict((name, row[name]) for name in ('recipe_id','revision','updated_by') + FIELDS)
    for field in DIMENSIONS + TIMING:
        result[field] = None if result[field] is None else str(result[field])
    result['revision'] = int(result['revision'])
    result['active'] = bool(result['active'])
    return result


def list_parts(search_text=''):
    search_text = (search_text or '').strip()
    if len(search_text) > 128:
        raise domain.RuleError('Search is limited to 128 characters.')
    pattern = '%' + search_text.replace('~','~~').replace('%','~%').replace('_','~_').replace('[','~[') + '%'
    where = ' OR '.join(field + " LIKE ? ESCAPE '~'" for field in KEY_FIELDS)
    rows = service._query('SELECT TOP (500) * FROM washheat.part_recipe WHERE ' + where + ' ORDER BY part_number,stage,press_recipe,qa_spec,press_qa', [pattern] * len(KEY_FIELDS))
    return [row_dict(row) for row in rows]


def resolve(identity, active_only=True):
    values = key(identity)
    rows = service._query('SELECT * FROM washheat.part_recipe WHERE ' + ('active=1 AND ' if active_only else '') +
                          ' AND '.join(field + '=?' for field in KEY_FIELDS), [values[field] for field in KEY_FIELDS])
    if len(rows) != 1:
        raise domain.RuleError('No ' + ('active ' if active_only else '') + 'exact part/stage/heat-spec/press-recipe/press-spec dimension entry.')
    return row_dict(rows[0])


def save(data, actor, recipe_id=None, expected_revision=0):
    record = validate(data)
    actor = domain.text(actor, 'authenticated actor')
    expected = domain.number(expected_revision, 'expected revision')
    if expected != expected.to_integral_value() or expected >= 2147483646:
        raise domain.RuleError('Invalid expected revision.')
    tx = system.db.beginTransaction(service.DATABASE)
    try:
        if recipe_id:
            recipe_id = domain.text(recipe_id, 'recipe id', 64)
            rows = service._query('SELECT * FROM washheat.part_recipe WITH (UPDLOCK,HOLDLOCK) WHERE recipe_id=?', [recipe_id], tx)
            if len(rows) != 1 or int(rows[0]['revision']) != int(expected):
                raise domain.RuleError('Entry changed; reload before saving.')
            if key(row_dict(rows[0])) != key(record):
                raise domain.RuleError('Lookup keys are immutable. Use New entry for another operation.')
            revision = int(expected) + 1
            args = [record[field] for field in FIELDS] + [revision, actor, recipe_id, int(expected)]
            changed = service._update('UPDATE washheat.part_recipe SET ' + ','.join(field+'=?' for field in FIELDS) +
                                      ',revision=?,updated_by=?,updated_at=SYSUTCDATETIME() WHERE recipe_id=? AND revision=?', args, tx)
            if changed != 1:
                raise domain.RuleError('Concurrent part update; reload before saving.')
        else:
            if expected != 0:
                raise domain.RuleError('New entry requires revision zero.')
            recipe_id, revision = str(uuid.uuid4()), 1
            values = key(record)
            existing = service._query('SELECT recipe_id FROM washheat.part_recipe WITH (UPDLOCK,HOLDLOCK) WHERE ' +
                                      ' AND '.join(field+'=?' for field in KEY_FIELDS), [values[field] for field in KEY_FIELDS], tx)
            if existing:
                raise domain.RuleError('This exact operation already exists. Select its row to edit.')
            columns = ('recipe_id',) + FIELDS + ('revision','updated_by')
            service._update('INSERT INTO washheat.part_recipe(' + ','.join(columns) + ') VALUES(' + ','.join('?' for _ in columns) + ')',
                            [recipe_id] + [record[field] for field in FIELDS] + [revision, actor], tx)
        record.update(recipe_id=recipe_id, revision=revision, updated_by=actor)
        service._update('INSERT INTO washheat.part_recipe_revision(recipe_id,revision,payload,changed_by) VALUES(?,?,?,?)',
                        [recipe_id, revision, domain.canonical(record), actor], tx)
        system.db.commitTransaction(tx)
        return record
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)


def history(recipe_id):
    return [json.loads(row['payload']) for row in service._query(
        'SELECT payload FROM washheat.part_recipe_revision WHERE recipe_id=? ORDER BY revision DESC',
        [domain.text(recipe_id, 'recipe id', 64)])]

