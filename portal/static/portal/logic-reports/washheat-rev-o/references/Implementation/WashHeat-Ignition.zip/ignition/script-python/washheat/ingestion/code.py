"""Gateway transactional capture admission. Receipt is permitted only after commit.

100 = raw observation, 200 = workflow events applied, 900 = durable review.
No PLC result, recipe, state or machine-control write exists in this module.
"""
import json
from decimal import Decimal
from copy import deepcopy
from washheat import capture, domain, service


def begin():
    tx = system.db.beginTransaction(service.DATABASE)
    try:
        service._query("SELECT run_id FROM washheat.handling_slot WITH (UPDLOCK,HOLDLOCK) WHERE slot_id=1", [], tx)
        return tx
    except:
        system.db.rollbackTransaction(tx)
        system.db.closeTransaction(tx)
        raise


def enroll(state, packet, recipe=None, actor=None):
    """Bind a NEW PLC_OBSERVED run to an explicit full part/load/epoch identity.

Dimensions, original load UTC and maximum soak come from the caller's reviewed
run data. Legacy LoadStamp is retained as identity, not assumed to be UTC.
"""
    expected = domain.new_run(state["run_id"], state["identity"], state["furnace"], state["initial_segment"],
                              state["loaded_at_ms"], state["dimensions"], state["max_qualifying_soak_seconds"], "PLC_OBSERVED")
    if domain.canonical(state) != domain.canonical(expected):
        raise domain.RuleError("Enrollment requires a canonical NEW PLC_OBSERVED run")
    capture.approved(packet)
    part = capture.identity(packet["Physical"]["Identity"])
    if capture.identity(packet["CurrentIdentity"]) != part:
        raise domain.RuleError("Physical and current slot identities differ")
    if dict((k, part[k]) for k in state["identity"]) != state["identity"]:
        raise domain.RuleError("Enrollment identity differs")
    if packet["Furnace"] != domain.FURNACES.index(state["furnace"]) + 1:
        raise domain.RuleError("Enrollment furnace differs")
    total = capture.qualifying(state, packet["Physical"])
    capture.integer(packet["SampleSequence"], "enrollment sample sequence", 1)
    if packet["Fault"] != 0 or packet["CaptureState"] not in (10, 30) or packet["ItemEmpty"] != 0:
        raise domain.RuleError("Enrollment requires an occupied, valid capture channel")
    slot = packet["Slot"] - 1
    if state["initial_segment"] != "%02d%s" % (slot // 4 + 1, "ABCD"[slot % 4]):
        raise domain.RuleError("Enrollment segment differs")
    updated = deepcopy(state)
    if recipe is not None:
        from washheat import catalog
        if catalog.key(recipe) != catalog.key(part):
            raise domain.RuleError('Catalogue lookup differs from frozen PLC identity')
        expected_dimensions = domain.calculate_reheat(recipe['od_in'], recipe['height_in'], recipe['circle_in'], 0)['inputs']
        if any(Decimal(updated['dimensions'][field]) != Decimal(expected_dimensions[field])
               if expected_dimensions[field] is not None and updated['dimensions'][field] is not None
               else updated['dimensions'][field] != expected_dimensions[field] for field in catalog.DIMENSIONS):
            raise domain.RuleError('Enrolled dimensions differ from the selected catalogue revision')
        updated['transfer_limit'] = domain.calculate_transfer_limit(dict((field, recipe[field]) for field in catalog.TIMING))
        updated['recipe_source'] = {'recipe_id': recipe['recipe_id'], 'revision': recipe['revision'], 'key': catalog.key(recipe)}
    updated["qualifying_soak_seconds"] = str(Decimal(total) / 1000)
    updated["plc_binding"] = {"identity": part, "slot": packet["Slot"], "epoch": capture.channel_key(packet)[:3]}
    key = capture.binding_key(packet, part)
    index = (packet["Furnace"] - 1) * 96 + slot
    tx = begin()
    try:
        if service._query("SELECT run_id FROM washheat.plc_binding WHERE controller=? AND channel_index=?", [packet["Controller"], index], tx):
            raise domain.RuleError("PLC channel already has a bound run")
        service._update("INSERT INTO washheat.run(run_id,furnace,phase,revision,snapshot) VALUES(?,?,?,?,?)",
                        [updated["run_id"], updated["furnace"], updated["phase"], 0, domain.canonical(updated)], tx)
        service._update("INSERT INTO washheat.plc_binding(binding_key,run_id,controller,channel_index,payload) VALUES(?,?,?,?,?)",
                        [key, updated["run_id"], packet["Controller"], index, domain.canonical(updated["plc_binding"])], tx)
        if recipe is not None:
            service._update('INSERT INTO washheat.run_recipe(run_id,recipe_id,recipe_revision,enrolled_by) VALUES(?,?,?,?)',
                            [updated['run_id'], recipe['recipe_id'], recipe['revision'], domain.text(actor, 'authenticated actor')], tx)
        system.db.commitTransaction(tx)
        return updated
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)


def enroll_from_catalog(packet, loaded_at_ms, actor):
    """Resolve an exact operation; persist its dimensions/revision in the new run."""
    import uuid
    from washheat import catalog
    identity = capture.identity(packet['CurrentIdentity'])
    recipe = catalog.resolve(identity)
    slot = packet['Slot'] - 1
    state = domain.new_run(str(uuid.uuid4()), identity, domain.FURNACES[packet['Furnace'] - 1],
                           '%02d%s' % (slot // 4 + 1, 'ABCD'[slot % 4]), domain.millis(loaded_at_ms),
                           dict((field, recipe[field]) for field in catalog.DIMENSIONS),
                           str(Decimal(packet['Physical']['MaximumSoakMs']) / 1000), 'PLC_OBSERVED')
    return enroll(state, packet, recipe, actor)


def hold(state, reason, tx):
    updated = deepcopy(state)
    if domain.state_number(updated) in (80, 90, 900):
        return updated
    updated["review_from_state"] = domain.state_number(updated)
    domain.set_state(updated, 900)
    updated.update(data_valid=False, review_reason=reason, version=updated["version"] + 1)
    count = service._update("UPDATE washheat.run SET phase=?,revision=?,snapshot=?,updated_at=SYSUTCDATETIME() WHERE run_id=? AND revision=?",
                            [updated["phase"], updated["version"], domain.canonical(updated), updated["run_id"], state["version"]], tx)
    if count != 1:
        raise domain.RuleError("Concurrent review transition")
    return updated


def ingest(packet, received_at_ms):
    key = capture.digest(capture.event_key(packet))
    channel = capture.digest(capture.channel_key(packet))
    payload = domain.canonical(packet)
    checksum = service._hash(payload)
    tx = begin()
    try:
        prior = service._query("SELECT payload_sha256,disposition FROM washheat.plc_capture WHERE capture_key=?", [key], tx)
        if prior:
            if prior[0]["payload_sha256"] != checksum:
                raise domain.RuleError("Capture identity collision")
            system.db.commitTransaction(tx)
            return int(prior[0]["disposition"])
        rows = []
        reason, disposition, state = None, 100, None
        original, savepoint = None, False
        try:
            if packet["PhysicalIsNew"]:
                part = capture.identity(packet["Physical"]["Identity"])
                rows = service._query("SELECT r.snapshot FROM washheat.plc_binding b JOIN washheat.run r ON r.run_id=b.run_id WHERE b.binding_key=?",
                                      [capture.binding_key(packet, part)], tx)
            else:
                rows = service._query("SELECT r.snapshot FROM washheat.plc_binding b JOIN washheat.run r ON r.run_id=b.run_id WHERE b.controller=? AND b.channel_index=?",
                                      [packet["Controller"], (packet["Furnace"] - 1) * 96 + packet["Slot"] - 1], tx)
            state = json.loads(rows[0]["snapshot"]) if rows else None
            previous = service._query("SELECT TOP (1) event_sequence FROM washheat.plc_capture WHERE channel_key=? ORDER BY event_sequence DESC", [channel], tx)
            sequence = int(previous[0]["event_sequence"]) + 1 if previous else 1
            if packet["Sequence"] != sequence:
                raise domain.RuleError("PLC capture sequence gap")
            if packet["PhysicalIsNew"] and state is None:
                raise domain.RuleError("Physical event has no enrolled part/load binding")
            samples = service._query("SELECT payload FROM washheat.plc_sample WHERE run_id=?", [state["run_id"]], tx) if state else []
            previous_sample = json.loads(samples[0]["payload"]) if samples else None
            derived = capture.events(state, packet, previous_sample) if state else []
            original = deepcopy(state)
            service._update("SAVE TRANSACTION capture_apply", [], tx)
            savepoint = True
            for event in derived:
                state = service.append_event(state["run_id"], event, state["version"], tx=tx, captured=True)
            if derived:
                disposition = 200
                index = (packet["Furnace"] - 1) * 96 + packet["Slot"] - 1
                if domain.state_number(state) in (80, 90):
                    index = None
                occupied = service._query("SELECT run_id FROM washheat.plc_binding WHERE controller=? AND channel_index=? AND run_id<>?",
                                          [packet["Controller"], index, state["run_id"]], tx)
                if occupied:
                    raise domain.RuleError("Return channel is already bound to another run")
                service._update("UPDATE washheat.plc_binding SET channel_index=?,payload=? WHERE run_id=?",
                                [index, domain.canonical(state["plc_binding"]), state["run_id"]], tx)
        except (domain.RuleError, KeyError, ValueError, TypeError) as error:
            if savepoint:
                service._update("ROLLBACK TRANSACTION capture_apply", [], tx)
                state = original
            reason, disposition = str(error)[:1024], 900
            if state:
                state = hold(state, reason, tx)
        service._update("INSERT INTO washheat.plc_capture(capture_key,channel_key,event_sequence,run_id,disposition,reason,payload,payload_sha256,received_at_ms) VALUES(?,?,?,?,?,?,?,?,?)",
                        [key, channel, packet["Sequence"], state["run_id"] if state else None, disposition, reason, payload, checksum, domain.millis(received_at_ms)], tx)
        system.db.commitTransaction(tx)
        return disposition
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)


def observe(packet, received_at_ms):
    """Persist a correlated sample; invalid readings latch the numbered review state."""
    tx = begin()
    try:
        index = (packet["Furnace"] - 1) * 96 + packet["Slot"] - 1
        rows = service._query("SELECT r.snapshot FROM washheat.plc_binding b JOIN washheat.run r ON r.run_id=b.run_id WHERE b.controller=? AND b.channel_index=?",
                              [packet["Controller"], index], tx)
        sequence = capture.integer(packet["EventSequence"], "sample event sequence")
        if rows and sequence > 0 and packet["Fault"] == 0:
            committed = service._query("SELECT disposition FROM washheat.plc_capture WHERE channel_key=? AND event_sequence=?",
                                       [capture.digest(capture.channel_key(packet)), sequence], tx)
            if not committed:
                # A physical edge may occur between reading Event and State.
                # Preserve sample age until that edge has been ingested.
                system.db.commitTransaction(tx)
                return
        for row in rows:
            state = json.loads(row["snapshot"])
            prior = service._query("SELECT payload FROM washheat.plc_sample WHERE run_id=?", [state["run_id"]], tx)
            previous = json.loads(prior[0]["payload"]) if prior else None
            sample = capture.sample(state, packet, previous, received_at_ms)
            if not sample["valid"]:
                hold(state, sample["reason"], tx)
            if prior:
                service._update("UPDATE washheat.plc_sample SET payload=? WHERE run_id=?", [domain.canonical(sample), state["run_id"]], tx)
            else:
                service._update("INSERT INTO washheat.plc_sample(run_id,payload) VALUES(?,?)", [state["run_id"], domain.canonical(sample)], tx)
        system.db.commitTransaction(tx)
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)


def invalidate(controller, index, reason):
    tx = begin()
    try:
        rows = service._query("SELECT r.snapshot FROM washheat.plc_binding b JOIN washheat.run r ON r.run_id=b.run_id WHERE b.controller=? AND b.channel_index=?", [controller, index], tx)
        for row in rows:
            hold(json.loads(row["snapshot"]), str(reason)[:1024], tx)
        system.db.commitTransaction(tx)
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)


def ingest_cdl(packet, received_at_ms):
    """Durably archive an uncorrelated legacy timer observation, without workflow events."""
    sequence = capture.integer(packet["Sequence"], "CDL event sequence", 1, 2147483647)
    channel = capture.digest(capture.cdl_key(packet))
    key = capture.digest([channel, sequence])
    payload = domain.canonical(packet)
    checksum = service._hash(payload)
    tx = begin()
    try:
        prior = service._query("SELECT payload_sha256,disposition FROM washheat.plc_capture WHERE capture_key=?", [key], tx)
        if prior:
            if prior[0]["payload_sha256"] != checksum:
                raise domain.RuleError("CDL observation identity collision")
            system.db.commitTransaction(tx)
            return int(prior[0]["disposition"])
        disposition, reason = 100, None
        try:
            capture.integer(packet["Kind"], "CDL kind", 1, 1)
            capture.integer(packet["Furnace"], "CDL furnace", 1, 2)
            capture.integer(packet["TimerMs"], "CDL raw timer", 0, 2147483647)
            previous = service._query("SELECT TOP (1) event_sequence FROM washheat.plc_capture WHERE channel_key=? ORDER BY event_sequence DESC", [channel], tx)
            expected = int(previous[0]["event_sequence"]) + 1 if previous else 1
            if sequence != expected:
                raise domain.RuleError("CDL observation sequence gap")
        except domain.RuleError as error:
            disposition, reason = 900, str(error)
        service._update("INSERT INTO washheat.plc_capture(capture_key,channel_key,event_sequence,run_id,disposition,reason,payload,payload_sha256,received_at_ms) VALUES(?,?,?,?,?,?,?,?,?)",
                        [key, channel, sequence, None, disposition, reason, payload, checksum, domain.millis(received_at_ms)], tx)
        system.db.commitTransaction(tx)
        return disposition
    except:
        system.db.rollbackTransaction(tx)
        raise
    finally:
        system.db.closeTransaction(tx)

